/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package birds;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuBar;
import javafx.stage.Stage;
//import javazoom.jl.player.Player;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Text;
import javafx.stage.Modality;

/**
 *
 * @author Abdelkader
 */
public class BirdsController implements Initializable {

    public BirdsController() {
        textFileName = "BirdsDatabase.txt";
        tree = new OrderedDictionary();
    }
    private final String textFileName;
    private boolean hasDictionary;
    private MediaPlayer medi;
    private OrderedDictionary tree;
    @FXML
    private Image picture; // current bird picture
    private String birdText; // current bird about
    private String birdName; // current bird name
    private BirdRecord currentBirdRecord; // current bird record
    @FXML
    private Button prevBtn;

    @FXML
    private MenuBar mainMenu;

    @FXML
    private Button findBtn;

    @FXML
    private TextField BirdNameSearchField;

    @FXML
    private ComboBox sizeCombo;

    @FXML
    private Button deleteBtn;

    @FXML
    private ImageView birdImageView;

    @FXML
    private MenuButton sizeMenuBtn;

    @FXML
    private MenuItem exit;

    @FXML
    private Button firstBtn;

    @FXML
    private Button stopBtn;

    @FXML
    private Button lastBtn;

    @FXML
    private Button playBtn;

    @FXML
    private Button nextBtn;

    @FXML
    private AnchorPane ap;
    @FXML
    private Label birdLabel;
    @FXML
    private Label birdNameLabel;

    @FXML
    public void exit() {
        Stage stage = (Stage) mainMenu.getScene().getWindow();
        stage.close();
    }

    @FXML
    public void loadDictionary() {//String fileName, OrderedDictionary dict) {

        Scanner input;
        String name;
        String sound;
        String image;
        int size;
        String about;
        DataKey dataKey;

        try {
            input = new Scanner(new File(textFileName));
            input.useDelimiter("\n");
            //have to read first line of about an determine size of bird, then call constructor for 
            //BirdRecord

            while (input.hasNext()) {

                size = Character.getNumericValue(input.next().charAt(0));//Integer.parseInt(input.next());
                name = input.next().trim();
                about = input.next().trim();
                dataKey = new DataKey(name, size);
                sound = name + ".mp3";
                image = name + ".jpg";
                BirdRecord birdRecord = new BirdRecord(name, size, about, sound, image);

                try {
                    tree.insert(birdRecord);
                } catch (DictionaryException ex) {

                    Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (IOException e) {
            System.out.println("There was an error in reading or opening the file: " + textFileName);
            System.out.println(e.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, e);
        }

        // create you dictionary/ tree here
        // fills dictionary
        // calls second fxml loader
        if (!tree.isEmpty()) {
            hasDictionary = true;
        }
        if (hasDictionary) {
            turnOnElements();
        }

        try {
            currentBirdRecord = tree.smallest();

            // turn on all the 
        } catch (DictionaryException ex) {
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
        }
       // System.out.println(currentBirdRecord.getDataKey().getBirdName());
        displayBirdRecord(currentBirdRecord);
    }

    @FXML
    public void first() {
        if (medi != null) {
            stop();
        }
        try {
            currentBirdRecord = tree.smallest();
            // find the smallest
        } catch (DictionaryException ex) {
            // System.out.println(DictionaryException.getString());
            displayAlert(ex.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        displayBirdRecord(currentBirdRecord);

    }

    @FXML
    public void last() {
        if (medi != null) {
            stop();
        }
        try {
            currentBirdRecord = (tree.largest());

        } catch (DictionaryException ex) {
            displayAlert(ex.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        displayBirdRecord(currentBirdRecord);
    }

    @FXML
    public void next() {
        if (medi != null) {
            stop();
        }
        try {
            currentBirdRecord = tree.successor(currentBirdRecord.getDataKey());
//            tree.setCurrentNodeKey(tree.successor(tree.getCurrentNodeKey()).getDataKey());

        } catch (DictionaryException ex) {
            displayAlert(ex.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        displayBirdRecord(currentBirdRecord);

    }

    @FXML
    public void previous() {
        if (medi != null) {
            stop();
        }
        try {
            currentBirdRecord = tree.predecessor(currentBirdRecord.getDataKey());

        } catch (DictionaryException ex) {
            displayAlert(ex.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);

        }
        //tree.setCurrentNodeKey(tree.predecessor(tree.getCurrentNodeKey()).getDataKey()); // sets the current datakey to the predescessos data key
        displayBirdRecord(currentBirdRecord);
    }

    @FXML
    public void delete() throws DictionaryException {
         if (medi != null) {
            stop();
        }
        BirdRecord temp = currentBirdRecord;
        BirdRecord b = new BirdRecord(currentBirdRecord.getDataKey(), currentBirdRecord.getAbout(), currentBirdRecord.getSound(), currentBirdRecord.getImage());

        try {
            currentBirdRecord = tree.successor(temp.getDataKey());

        } catch (DictionaryException ex) {
            //System.out.println("NO successor");
            try {
                currentBirdRecord = tree.predecessor(temp.getDataKey());//tree.predeccessor(temp.getDataKey());

            } catch (DictionaryException exx) {
                //System.out.println("Only one left");
                turnOffElements();
                displayAlert("No more Birds in the dataBase to show");
            }
        }
        
        displayBirdRecord(currentBirdRecord);
        // delete the node
        try {
            tree.remove(temp.getDataKey());
            displayBirdRecord(currentBirdRecord);
        } catch (DictionaryException ex) {
            displayAlert(ex.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    public void find() {
         if (medi != null) {
            stop();
        }
        // take input from the Text fields and make them 
        String nameInput;
        nameInput = BirdNameSearchField.getText().trim();
        int sizeInput = 1;
        String sizeMenuText = sizeCombo.getValue().toString().trim();
        if (sizeMenuText.equals("Medium")) {
            sizeInput = 2;
        } else if (sizeMenuText.equals("Large")) {
            sizeInput = 3;
        }
        //Pull info int a new datakey to search for
        DataKey findBird = new DataKey(nameInput, sizeInput);
        BirdRecord findResult = null;
        try {
            // search for new data key
            findResult = tree.find(findBird);
        } catch (DictionaryException ex) {
            // do something here,
            // Display a new scene with the exception statement being said
            displayAlert(ex.getMessage());
            Logger.getLogger(BirdsController.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (findResult != null) {
            currentBirdRecord = findResult;
            displayBirdRecord(currentBirdRecord);
        }

    }

    @FXML
    public void play() throws MalformedURLException {

        File soundFile = new File("C:\\Users\\Sean_2\\Documents\\NetBeansProjects\\Birds\\src\\sounds\\" + currentBirdRecord.getSound());
        String localUrl = soundFile.toURI().toURL().toString();
        Media sound = new Media(localUrl);
        medi = new MediaPlayer(sound);
        medi.play();
        playBtn.setDisable(true);
        stopBtn.setDisable(false);
       
    }

    @FXML
    public void stop() {
        medi.stop();
        playBtn.setDisable(false);
        stopBtn.setDisable(true);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // set all items to be false
        turnOffElements();
        playBtn.setStyle("-fx-background-color: green; ");
        stopBtn.setStyle("-fx-background-color: green; ");
        prevBtn.setStyle("-fx-background-color: lawngreen; ");
        firstBtn.setStyle("-fx-background-color: lawngreen; ");
        lastBtn.setStyle("-fx-background-color: lawngreen; ");
        nextBtn.setStyle("-fx-background-color: lawngreen; ");
        deleteBtn.setStyle("-fx-background-color: red; ");
        findBtn.setStyle("-fx-background-color: Cyan; ");

        sizeCombo.getItems().addAll(
                "Small",
                "Medium",
                "Large"
        );

    }

    private void turnOffElements() {
        ap.setVisible(false);

    }

    private void turnOnElements() {
        ap.setVisible(true);
        //  playBtn.setStyle("-fx-background-color-: green; ");
        // stopBtn.setStyle("-fx-background-color-: green; ");
//        

    }

    private void displayBirdRecord(BirdRecord r) {
        // set the Bird about
        birdText = r.getAbout();
        //System.out.println(birdText);
        // set bird name
        birdName = r.getDataKey().getBirdName();

        if (!"".equals(birdText)) {
            birdLabel.setText(birdText);

        } else {
            System.out.println("No about information found in the Bird Record");
        }
        // show the birb name
        if (!"".equals(birdName)) {
            birdNameLabel.setText(birdName);
        } else {
            System.out.println("No Bird name information found in Bird Record DataKey");
        }

        String birdImageName = "file:C:\\Users\\Sean_2\\Documents\\NetBeansProjects\\Birds\\src\\images\\" + r.getImage();
       // System.out.println(birdImageName);
        // set bird image
        //System.out.println(birdImageName);
        picture = new Image(birdImageName);//(BirdsController.class.getResourceAsStream(birdImageName));
        //System.out.println("k");
        if (picture != null) {
            birdImageView.setImage(picture);
        } else {
            System.out.println("No image File found in Bird Record");
        }
        // show the bird text

    }

    private void displayAlert(String msg) {
        try {

            FXMLLoader loader = new FXMLLoader(getClass().getResource("ExceptionPage.fxml"));
            Parent ERROR = loader.load();
            ExceptionPageController controller = (ExceptionPageController) loader.getController();

            Scene scene = new Scene(ERROR);
            Stage stage = new Stage();
            stage.setScene(scene);

            stage.getIcons().add(new Image("file:src/birds/WesternBackground.png"));
            controller.setAlertText(msg);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();

        } catch (IOException ex1) {

        }
    }

}

package birds;

import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sean_2
 */
public class OrderedDictionary implements OrderedDictionaryADT {

    private class Node<T> implements BinaryNodeInterface<T> {

        private T data;
        //private 
        public Node<T> left;
        //private
        public Node<T> right;
        //private 
        public Node<T> parent;

        public Node() {
            this(null);  // call next constructor
        } // end default constructor

        public Node(T dataPortion) {
            this(dataPortion, null, null);
// call next constructor
        } // end constructor

        public Node(T dataPortion, Node< T> leftChild, Node< T> rightChild) {
            data = dataPortion;
            left = leftChild;
            right = rightChild;
        } // end constructor

        @Override
        public T getData() {
            return data;
        } // end getData

        @Override
        public void setData(T newData) {
            data = newData;
        } // end setData

        @Override
        public Node<T> getLeftChild() {
            return left;
        } // end getLeftChild

        @Override
        public Node<T> getRightChild() {
            return right;
        } // end getRightChild

        @Override
        public Node<T> getParent() {
            return parent;
        }

        @Override
        public void setLeftChild(BinaryNodeInterface< T> leftChild) {
            left = (Node< T>) leftChild;
        } // end setLeftChild

        @Override
        public void setRightChild(BinaryNodeInterface<T> rightChild) {
            right = (Node<T>) rightChild;
        }

        @Override
        public void setParent(BinaryNodeInterface<T> parentPass) {
            parent = (Node<T>) parentPass;
        }

        @Override
        public boolean hasLeftChild() {
            return left != null;
        } // end hasLeftChild

        @Override
        public boolean hasRightChild() {
            return right != null;
        }

        @Override
        public boolean hasParent() {
            return parent != null;
        }

        @Override
        public boolean isLeaf() {
            return (left == null) && (right == null);
        } // end isLeaf    Unit     7 - 32

        @Override
        public BinaryNodeInterface< T> copy() {

            Node< T> newRoot = new Node< T>(data);
            if (left != null) {
                newRoot.left = (Node< T>) left.copy();
            }
            if (right != null) {
                newRoot.right = (Node< T>) right.copy();
            }
            return newRoot;
        } // end copy

        @Override
        public int getHeight() {
            return getHeight(this); // call private getHeight
        } // end getHeight

        private int getHeight(Node< T> node) {
            int height = 0;
            if (node != null) {
                height = 1 + Math.max(getHeight(node.left), getHeight(node.right));
            }
            return height;
        } // end getHeight

        @Override
        public int getNumberOfNodes() {
            int leftNumber = 0;
            int rightNumber = 0;
            if (left != null) {
                leftNumber = left.getNumberOfNodes();
            }
            if (right != null) {
                rightNumber = right.getNumberOfNodes();
            }
            return 1 + leftNumber + rightNumber;
        } // end getNumberOfNodes    
    } // end BinaryNod

    private Node root; // the parent of the tree
    private DataKey current;

    public DataKey getCurrentNodeKey() {
        return current;
    }

    public void setCurrentNodeKey(DataKey k) {
        current = k;
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node n) {
        root = n;
    }

    /* Returns the Record object with key k, or It throws a DictionaryException
       says: "There is no record matches the given key", if such a record
       is not in the dictionary. 

       @param k
       @return BirdRecord
       @throws DictionaryException
     */
    @Override
    public BirdRecord find(DataKey k) throws DictionaryException {

        Node focusNode = root;
        BirdRecord b = (BirdRecord) focusNode.getData();
        //System.out.println("looking k:" + k.getBirdSize()+k.getBirdName() );
//        System.out.println("find b.getDataKey() : " + b.getDataKey().getBirdSize()+b.getDataKey().getBirdName());
        while (b.getDataKey() != k) {
//            System.out.println("find k:" + k.getBirdSize()+k.getBirdName() );
//        System.out.println("find b.getDataKey() : " + b.getDataKey().getBirdSize()+b.getDataKey().getBirdName());

            b = (BirdRecord) focusNode.getData(); // reassignned every loop
            int comp = b.getDataKey().compareTo(k);
            // int comp = k.compareTo(b.getDataKey()); // compare the datakeys

            switch (comp) { // evaluate the comparesion
                case 1: // the search dataKey is smaller than the focusNode data go to the left child
                    focusNode = focusNode.getLeftChild();
                    break;
                case 0: // same
                    //System.out.println("Here in find");
                    // System.out.println("found b.getDataKey() : " + b.getDataKey().getBirdSize()+b.getDataKey().getBirdName());
                    return b; // return the birdRecord related
                // break;
                case -1: // the search dataKey is greatter than the focusNode data
                    focusNode = focusNode.getRightChild();
                    break;
            }

            if (focusNode == null) { // this value is empty, it is a leaf and has no more nodes below it to compare to.
                System.out.println("not found:" + k.getBirdSize() + k.getBirdName());
                throw new DictionaryException("There is no record matches the given key");
            }
        }

        return (BirdRecord) root.getData();
    }

    private Node findNode(DataKey k) throws DictionaryException {

        Node focusNode = root;
        if (focusNode == null) {
            throw new DictionaryException("There is no root data");
        }
        BirdRecord b = (BirdRecord) focusNode.getData();
        //System.out.println("looking k:" + k.getBirdSize() + k.getBirdName());
        while (b.getDataKey() != k) {
            //System.out.println(b.getDataKey().getBirdName() + " " + b.getDataKey().getBirdSize());
            b = (BirdRecord) focusNode.getData(); // reassignned every loop
            int comp = b.getDataKey().compareTo(k);
            // int comp = k.compareTo(b.getDataKey()); // compare the datakeys

            switch (comp) { // evaluate the comparesion
                case 1: // the search dataKey is smaller than the focusNode data go to the left child
                    focusNode = focusNode.getLeftChild();
                    break;
                case 0: // same
                    // System.out.println("found b.getDataKey() : " + b.getDataKey().getBirdSize() + b.getDataKey().getBirdName());
                    return focusNode; // return the node holdinging k
                //b; // return the birdRecord related
                // break;
                case -1: // the search dataKey is greatter than the focusNode data
                    focusNode = focusNode.getRightChild();
                    break;
            }

            if (focusNode == null) { // this value is empty, it is a leaf and has no more nodes below it to compare to.
                //System.out.println("Here");
                // System.out.println("not found k:" + k.getBirdSize() + k.getBirdName());
                throw new DictionaryException("There is no record matches the given key");
            }
        }
        // System.out.println("not found:" + k.getBirdSize() + k.getBirdName());
        return root;
    }

    /* Inserts r into the ordered dictionary. It throws a DictionaryException 
       if a record with the same key as r is already in the dictionary.  

       @param r
       @throws DictionaryException
     */
    @Override
    public void insert(BirdRecord r) throws DictionaryException {

        Node n = new Node(r); //create new node
        if (root == null) {
            root = n;
            //System.out.println("Made new root in insert");
           // System.out.println("New node's data key is " + ((BirdRecord) n.getData()).getDataKey());
        } else {
            Node focus = root;
            Node parent;
            while (true) {
                parent = focus;
                //focus.getData();

                int compare = ((BirdRecord) focus.getData()).getDataKey().
                        compareTo(((BirdRecord) n.getData()).getDataKey());

                switch (compare) {
                    case 1:
                        // here the information in focus is bigger than the information in n
                        focus = focus.getLeftChild();

                        if (focus == null) { // 
                            parent.setLeftChild(n);
                            n.setParent(parent);

                            //System.out.println("New node's data key is " + ((BirdRecord) n.getData()).getDataKey());
                            return;
                        }

                        break;
                    case 0:
                        // Here the code has found an exact match of the birdRecord in the dictionary tree
                        throw new DictionaryException("Dictionary already contains this BirdRecord");
                    case -1:
                        focus = focus.getRightChild();

                        if (focus == null) {
                            parent.setRightChild(n);
                            n.setParent(parent);
                            //System.out.println("New node's data key is " + ((BirdRecord) n.getData()).getDataKey());
                            return;
                        }
                        break;
                }

            }
        }

    }
    
    
    
////    @Override
////    public void insert(BirdRecord r) throws DictionaryException {
////
////        Node n = new Node(r); //create new node
////        if (root == null) {
////            root = n;
////        } else {
////            Node focus = root;
////            Node parent;
////            while (true) {
////                parent = focus;
////                focus.getData();
////
////                int compare = ((BirdRecord) focus.getData()).getDataKey().
////                        compareTo(((BirdRecord) n.getData()).getDataKey());
////
////                switch (compare) {
////                    case 1:
////                         here the information in focus is bigger than the information in n
////                        focus = focus.getLeftChild();
////
////                        if (focus == null) { // 
////                            parent.setLeftChild(n);
////                            n.setParent(parent);
////                            return;
////                        }
////
////                        break;
////                    case 0:
////                         Here the code has found an exact match of the birdRecord in the dictionary tree
////                        throw new DictionaryException("Dictionary already contains this BirdRecord");
////                    case -1:
////                        focus = focus.getRightChild();
////
////                        if (focus == null) {
////                            parent.setRightChild(n);
////                            n.setParent(parent);
////                            return;
////                        }
////                        break;
////                }
////
////            }
////        }
////
////    }

    /*  Removes the record with Key k from the dictionary. It throws a 
        DictionaryException says: "No such record key exists", if the record
        is not in the dictionary. 
             
       @param k
       @throws DictionaryException
     */
    @Override
    public void remove(DataKey k) throws DictionaryException {

        Node holder = findNode(k); // find the node to be removed

        if (holder == null) { // thow the exception
           // System.out.println("Trying to remove null root");
            throw new DictionaryException("No such record key exists");
        }

        if (holder.isLeaf()) { // //case 1 : Node being remove has no chldren
            //get parent of this node
            if (holder == root) { //if removing root
                //System.out.println("Root is a leaf and was removed");
                //System.out.println("Root key is: " + ((BirdRecord) holder.getData()).getDataKey());
                setRoot(null);

            } else {
                Node parent = holder.getParent();
                //System.out.println("Datakey of holder's parent is: " + ((BirdRecord) parent.getData()).getDataKey());
                //System.out.println("Removing a leaf that is not a root");

                if (parent.getRightChild() == holder) //if right child of parent
                {
                    //System.out.println("node is a right child of parent");
                    parent.setRightChild(null);
                } else { //if left child of parent
                    //System.out.println("node is a left child of parent");
                    parent.setLeftChild(null);
                }
            }
        } else if (onlyOneChild(holder)) { // case 2: Node to be remove has only one child

            if (holder == root) { //if removing root
               // System.out.println("Removing root that has one child");
                Node child;
                if (holder.hasLeftChild()) { // if root has left child
                    //System.out.println("Deleting connection between root and left child");
                    child = holder.getLeftChild();
                } else { //if root has right child
                    //System.out.println("Deleting connection between root and right child");
                    child = holder.getRightChild();
                }
                //System.out.println("Reassigning root");
                setRoot(child);
//                if (child != null) {
//                    System.out.println("New root key is: " + ((BirdRecord) child.getData()).getDataKey());
//                }

            } else { //if removing node that isn't a parent

                Node parent = holder.getParent(); // get parent

                if (holder == parent.getRightChild()) { // if it is the right child
                    Node child;// get the single child of the holder
                    if (holder.hasLeftChild()) {
                        child = holder.getLeftChild();
                    } else {
                        child = holder.getRightChild();
                    }
                    //System.out.println("Deleting connection between node and right child");
                    // set the parents right child to be equal to the child
                    parent.setRightChild(child);
                    // set the child's parent to be equal to the parent
                    child.setParent(parent);

                } else if (holder == parent.getLeftChild()) { //if left child
                    Node child;
                    if (holder.hasLeftChild()) {
                        child = holder.getLeftChild();
                    } else {
                        child = holder.getRightChild();
                    }
                    //System.out.println("Deleting connection between node and left child");
                    parent.setLeftChild(child);
                    child.setParent(parent);
                }

            }

        } else if (holder.getRightChild() != null && holder.getLeftChild() != null) //  !onlyOneChild(holder)) 
        { // case 3: holder has two children
//            System.out.println("Replacing node that has two children");
//            System.out.println("Holder's left child is : " + (((BirdRecord) holder.getLeftChild().getData()).getDataKey()));
//            System.out.println("Holder's right child is : " + (((BirdRecord) holder.getRightChild().getData()).getDataKey()));
            // get the successor
            BirdRecord s = successor(((BirdRecord) holder.getData()).getDataKey()); //  returns the successores' bird records
            //System.out.println("successor root key is: " + s.getDataKey());
            Node suc = findNode(s.getDataKey()); // get the successors node

            if (suc.isLeaf()) { // case 3a : if the successor is a leaf
                Node sucPar = suc.getParent();
                if (holder == root) { //if root being removed, set suc to root's references and remove
                    //suc's prior references to null
                    //System.out.println("Replacing root with its successor");

//                    if (sucPar == null) {
//                       // System.out.println("successor's parent is null");
//                    }
//                    if (suc == null) {
//                        System.out.println("successor is null");
//                    }
                    suc.setLeftChild(holder.getLeftChild()); //set successor's children to be past root's children
                    suc.getLeftChild().setParent(suc);
                    suc.setRightChild(holder.getRightChild());
                    suc.getRightChild().setParent(suc);
                    sucPar.setLeftChild(null); //set successor's original parent's child 
                    suc.setParent(null);
                    setRoot(suc);
                   // System.out.println("new root is: " + (((BirdRecord) suc.getData()).getDataKey()));
                } else { //if not root but still a leaf

                   // System.out.println("Holder's left child is : " + (((BirdRecord) holder.getLeftChild().getData()).getDataKey()));
                    //System.out.println("Holder's right child is : " + (((BirdRecord) holder.getRightChild().getData()).getDataKey()));

                   // System.out.println("successor is a leaf that is being removed");
                    // set the successor's parents appropriate child to be null

                    //set holder's children to now be successor's children
                    suc.setLeftChild(holder.getLeftChild());
                    suc.setRightChild(holder.getRightChild());
                    suc.getLeftChild().setParent(suc);
                    suc.getRightChild().setParent(suc);

//                    System.out.println("suc's left child is : " + (((BirdRecord) suc.getLeftChild().getData()).getDataKey()));
//                    System.out.println("suc's right child is : " + (((BirdRecord) suc.getRightChild().getData()).getDataKey()));
//                    System.out.println("suc's right child's parent is : " + (((BirdRecord) suc.getRightChild().getParent().getData()).getDataKey()));
//                    System.out.println("suc's left child's parent is : " + (((BirdRecord) suc.getRightChild().getParent().getData()).getDataKey()));

                    //set holder's parent to now be successor's parent
                    suc.setParent(holder.getParent());
                    //check to see if holder was a right child and assign suc as a right or left
                    if (holder.getParent().getLeftChild() == holder) //if holder was a left child
                    {
                        holder.getParent().setLeftChild(suc);
                    } else if (holder.getParent().getRightChild() == holder) {
                        holder.getParent().setRightChild(suc);
                    }
                    //delete references to holder
                    holder.setParent(null);
                    holder.setLeftChild(null);
                    holder.setRightChild(null);
                 
                }
            } else if (suc.getRightChild() != null) { // case 3b: if the successor has one child
                //System.out.println("successor has one child");
                Node sucPar = suc.getParent();
               // System.out.println("successor's past parent is : " + ((BirdRecord) sucPar.getData()).getDataKey());
                Node child = suc.getRightChild();
               // System.out.println("successor's past child is : " + ((BirdRecord) child.getData()).getDataKey());
                if (holder == root) {
                   // System.out.println("removing root");
                    //need to attach successor's child to successor's parent and replace root with successor
                    sucPar.setLeftChild(child);
                    child.setParent(sucPar);

                    suc.setLeftChild(holder.getLeftChild());
                    suc.setRightChild(holder.getRightChild());
                    // set holder's children's parent to be suc
                    suc.getLeftChild().setParent(suc);
                    suc.getRightChild().setParent(suc);

                    holder.setLeftChild(null);
                    holder.setRightChild(null);
                    setRoot(suc);

                } else {
                    // take the right child of successor and make it the left child of successor's parent
                    sucPar.setLeftChild(child);
                    child.setParent(sucPar);

                    // set suc's parent to be the holder's parent 
                    suc.setParent(holder.getParent());
                    // set suc's children to be holder's children
                    suc.setLeftChild(holder.getLeftChild());
                    suc.setRightChild(holder.getRightChild());
                    // set holder's children's parent to be suc
                    suc.getLeftChild().setParent(suc);
                    suc.getRightChild().setParent(suc);
                    // remove all connections from holder
                    holder.setParent(null);
                    holder.setLeftChild(null);
                    holder.setRightChild(null);
                }
            }
        }

    }
        /*
//        Node parent = root;
//        Node current = root;
//        boolean isLeftChild = false;
//        while (((BirdRecord)current.getData()).getDataKey().compareTo(k) == 0) {
//            parent = current;
//            if (((BirdRecord)current.getData()).getDataKey().compareTo(k) > 1) {
//                isLeftChild = true;
//                current = current.left;
//            } else {
//                isLeftChild = false;
//                current = current.right;
//            }
//            if (current == null) {
//                //return false;
//            }
//        }
//        //if i am here that means we have found the node
//        //Case 1: if node to be deleted has no children
//        if (current.left == null && current.right == null) {
//            if (current == root) {
//                root = null;
//            }
//            if (isLeftChild == true) {
//                parent.left = null;
//            } else {
//                parent.right = null;
//            }
//        } //Case 2 : if node to be deleted has only one child
//        else if (current.right == null) {
//            if (current == root) {
//                root = current.left;
//            } else if (isLeftChild) {
//                parent.left = current.left;
//            } else {
//                parent.right = current.left;
//            }
//        } else if (current.left == null) {
//            if (current == root) {
//                root = current.right;
//            } else if (isLeftChild) {
//                parent.left = current.right;
//            } else {
//                parent.right = current.right;
//            }
//        } else if (current.left != null && current.right != null) {
//
//            //now we have found the minimum element in the right sub tree
//            BirdRecord s = successor(((BirdRecord)current.getData()).getDataKey());
//            Node successor = findNode(s.getDataKey());
//            if (current == root) {
//                root = successor;
//            } else if (isLeftChild) {
//                parent.left = successor;
//            } else {
//                parent.right = successor;
//            }
//            successor.left = current.left;
//        }
//       // return true;
//    }

//        Node parent = root;
//        Node cur;// = root;
//        boolean isLeftChild = false;
////        while (cur.data != k) {
////            parent = cur;
////            if (cur.data > k) {
////                isLeftChild = true;
////                cur = cur.left;
////            } else {
////                isLeftChild = false;
////                cur = cur.right;
////            }
////            if (cur == null) {
////               // return false;
////            }
////        }
//        cur = findNode(k);
//        parent = cur.getParent();
//        if (cur.getParent().getLeftChild() == cur) isLeftChild =true;
//        
//        //if i am here that means we have found the node
//        //Case 1: if node to be deleted has no children
//        if (!cur.hasLeftChild() && !cur.hasRightChild()) {
//            if (cur == root) {
//                root = null;
//            }
//            if (isLeftChild == true) {
//                parent.setLeftChild(null);
//            } else {
//                parent.setRightChild(null);
//            }
//        } //Case 2 : if node to be deleted has only one child
//        else if (!cur.hasRightChild()) {
//            if (cur == root) {
//                root = cur.getLeftChild();
//                root.setParent(null);
//            } else if (isLeftChild) {
//                parent.setLeftChild(cur.getLeftChild());
//            } else {
//                parent.setRightChild( cur.getLeftChild());
//            }
//        } else if (!cur.hasLeftChild()) {
//            if (cur == root) {
//                root = cur.getLeftChild();
//                root.setParent(null);
//            } else if (isLeftChild) {
//                parent.setLeftChild(cur.getRightChild());
//            } else {
//                parent.setRightChild(cur.getRightChild());
//            }
//        } else if (cur.hasLeftChild() && cur.hasRightChild()) {
//
//            //now we have found the minimum element in the right sub tree
//          
//            BirdRecord s = successor(((BirdRecord) cur.getData()).getDataKey());
//            Node successor = findNode(s.getDataKey());
//            if (cur == root) {
//                root = successor;
//            } else if (isLeftChild) {
//                parent.setLeftChild( successor);
//            } else {
//                parent.setRightChild(successor);
//            }
//            successor.setLeftChild(cur.getLeftChild());
//        }
//        //return true;
//    }

        Node holder = findNode(k); // find the node to be removed

        if (holder == null) { // thow the exception
            System.out.println("Out");
            throw new DictionaryException("No such record key exists");
        }

        if (holder.isLeaf()) { // //case 1 : NOde being remove has no chldren
            //get parent of this node
            if (holder == root) {
                setRoot(null);

            } else {
                Node parent = holder.getParent();
                // check which child it is
                if (parent.getRightChild() == holder) {
                    // set parent's child to null.
                    // goodbye holdder; 
                    parent.setRightChild(null);
                } else {
                    parent.setLeftChild(null);
                }
                holder.setParent(null);
            }
        } else if (onlyOneChild(holder)) { // case 2: Node to be remove has only one child

            if (holder == root) {
                Node child;
                if (holder.hasLeftChild()) { // get the left child of the node to be removed
                    child = holder.getLeftChild();
                    holder.setLeftChild(null);
                } else {//if (holder.hasRightChild()) { // get the right child of the node to be removed
                    child = holder.getRightChild();
                    holder.setRightChild(null); // removes holders connections
                }
                setRoot(child);

            } else {

                Node parent = holder.getParent(); // get parent

                if (holder == parent.getRightChild()) { // if it is the right child
                    Node child;// get the single child of the holder
                    if (holder.hasLeftChild()) {
                        child = holder.getLeftChild();
                    } else {
                        child = holder.getRightChild();
                    }
                    //  set the parents right child to be equal to the child
                    parent.setRightChild(child);
                    // set the child's parent to be equal to the parent
                    child.setParent(parent);

                } else if (holder == parent.getLeftChild()) {
                    Node child;
                    if (holder.hasLeftChild()) {
                        child = holder.getLeftChild();
                    } else {
                        child = holder.getRightChild();
                    }
                    parent.setLeftChild(child);
                    child.setParent(parent);
                }

            }

        } else if (!onlyOneChild(holder)) { // case 3: holder has two chilren
            // get the successor
            BirdRecord s = successor(((BirdRecord) holder.getData()).getDataKey()); //  retruns the successores' birdreocrds
            Node suc = findNode(s.getDataKey()); // get the successors node

            if (suc.isLeaf()) { // case 3a : if the successor is a leaf
                Node sucPar = suc.getParent();
                if (holder == root) { //if root being removed, set suc to root's references and remove
                    // suc's prior references to null
                    sucPar.setLeftChild(null);
                    suc.setParent(null);
                    suc.setLeftChild(holder.getLeftChild());
                    suc.getLeftChild().setParent(suc);
                    suc.setRightChild(holder.getRightChild());
                    suc.getRightChild().setParent(suc);
                } else {

                    // set the successor's parents appropriate child to be null
                    if (suc == sucPar.getLeftChild()) {
                        sucPar.setLeftChild(null);
                    } else {
                        sucPar.setRightChild(null);
                    }
                    // set suc's parent to be the holder's parent 
                    suc.setParent(holder.getParent());
                    // set suc's children to be holder's children
                    suc.setLeftChild(holder.getLeftChild());
                    suc.setRightChild(holder.getRightChild());
                    // set holder's children's parent to be suc
                    suc.getLeftChild().setParent(suc);
                    suc.getRightChild().setParent(suc);
                    // remove all connections from holder
                    holder.setParent(null);
                    holder.setLeftChild(null);
                    holder.setRightChild(null);
                }
            } else if (onlyOneChild(suc)) { // case 3b: if the successor has one child
                Node sucPar = suc.getParent();
                Node child = suc.getRightChild();
                if (holder == root) {
                    //need to attach successor's child to successor's parent and replace root with successor
                    sucPar.setLeftChild(child);
                    child.setParent(sucPar);

                    suc.setLeftChild(holder.getLeftChild());
                    suc.setRightChild(holder.getRightChild());
                    // set holder's children's parent to be suc
                    suc.getLeftChild().setParent(suc);
                    suc.getRightChild().setParent(suc);

                    holder.setLeftChild(null);
                    holder.setRightChild(null);

                } else {

                    if (suc.hasRightChild()) {
                        // holder := node we are removeing
                        // suc := node we are replacing holder with

                        // take the right child of successor and make it the left child of successos parent
                        sucPar.setLeftChild(child);
                        child.setParent(sucPar);

                        // set suc's parent to be the holder's parent 
                        suc.setParent(holder.getParent());
                        // set suc's children to be holder's children
                        suc.setLeftChild(holder.getLeftChild());
                        suc.setRightChild(holder.getRightChild());
                        // set holder's children's parent to be suc
                        suc.getLeftChild().setParent(suc);
                        suc.getRightChild().setParent(suc);
                        // remove all connections from holder
                        holder.setParent(null);
                        holder.setLeftChild(null);
                        holder.setRightChild(null);
                    }
                }
            }

        }
    }
  */  
    private boolean onlyOneChild(Node par) {

        if ((par.hasLeftChild() && par.hasRightChild()) // has two children 
                || par.isLeaf()) { //!par.hasLeftChild() && !par.hasLeftChild()) { // has no children; is leaf
            return false;
        } else { // therefore 1 child
            return true;
        }

    }

    /* Returns the successor of k (the record from the ordered dictionary 
       with smallest key larger than k); It throws a DictionaryException says:
       "There is no successor for the given record key", if the given key has 
       no successor. The given key DOES NOT need to be in the dictionary. 
         
       @param k
       @return BirdRecord
       @throws DictionaryException
     */
    @Override
    public BirdRecord successor(DataKey k) throws DictionaryException {

        Node focus = root;
        BirdRecord suc = null;
        while (focus != null) {
            int comp = ((BirdRecord) focus.getData()).getDataKey().compareTo(k);
            if (comp == 0 || comp == -1) {
                focus = focus.getRightChild();
            } else if (comp == 1) {
                suc = (BirdRecord) focus.getData();
                focus = focus.getLeftChild();
            }

        }
        if (suc == null || suc.getDataKey().compareTo(k) == -1 || suc.getDataKey().compareTo(k) == 0) {
            throw new DictionaryException("There is no successor for the given record key");
        }
        return suc;
    }


    /* Returns the predecessor of k (the record from the ordered dictionary 
       with largest key smaller than k; It throws a DictionaryException says:
       "There is no predecessor for the given record key", if the given key has 
       no predecessor. The given key DOES NOT need to be in the dictionary.  
     
       @param k
       @return BirdRecord
       @throws DictionaryException
     */
    @Override
    public BirdRecord predecessor(DataKey k) throws DictionaryException {

        Node focus = root;
        BirdRecord pred = null;
        while (focus != null) {
            int comp = ((BirdRecord) focus.getData()).getDataKey().compareTo(k);
            if (comp == 0 || comp == 1) {
                focus = focus.getLeftChild();
            } else if (comp == -1) {
                pred = (BirdRecord) focus.getData();
                focus = focus.getRightChild();
            }

        }
        if (pred == null || pred.getDataKey().compareTo(k) == 1 || pred.getDataKey().compareTo(k) == 0) {
            throw new DictionaryException("There is no predecessor for the given record key");
        }
        return pred;
    }

    /* Returns the record with smallest key in the ordered dictionary. 
       It throws a DictionaryException says:"Dictionary is empty", if the 
       dictionary is empty.   

       @return BirdRecord
       @throws DictionaryException
     */
    @Override
    public BirdRecord smallest() throws DictionaryException {
        Node focusNode;
        focusNode = root;
        while (focusNode.hasLeftChild()) { // keept goin down left
            focusNode = focusNode.getLeftChild();
        }
        if (isEmpty() == true) {
            throw new DictionaryException("Dictionary is empty");
        }
        return (BirdRecord) focusNode.getData();
    }

    /* Returns the record with largest key in the ordered dictionary. 
       It throws a DictionaryException says:"Dictionary is empty", if the 
       dictionary is empty.  
       @return BirdRecord
       @throws DictionaryException
     */
    @Override
    public BirdRecord largest() throws DictionaryException {
        Node focusNode;
        focusNode = root;

        while (focusNode.hasRightChild()) { // kept goin down right
            focusNode = focusNode.getRightChild();
        }
        if (isEmpty() == true) {
            throw new DictionaryException("Dictionary is empty");
        }

        BirdRecord b = (BirdRecord) focusNode.getData();
        // System.out.println(b.getAbout());
        return b;

    }

//        Node cur = root;
//        while (cur.getRightChild() != null) {
//            cur = cur.getRightChild();
//        }
//        if (isEmpty() == true) {
//            throw new DictionaryException("Dictionary is empty");
//        }
//        return (BirdRecord)cur.getData();
    /* Returns true if the dictionary is empty, and true otherwise. 

       @return boolean
     */
    @Override
    public boolean isEmpty() {
        if (root != null) {
            return false;
        }
        return true;

    }

}

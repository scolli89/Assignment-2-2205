package birds;

public class DataKey {

    private final String _birdName;
    private final int _birdSize;

    // default constructor
    public DataKey(String name, int size) {
        _birdName = name;
        _birdSize = size;
    }

    public String getBirdName() {
        return _birdName;
    }

    public int getBirdSize() {
        return _birdSize;
    }
    // other constructors

    /**
     * Returns 0 if this DataKey is equal to k, returns -1 if this DataKey is
     * smaller than k, and it returns 1 otherwise.
     * @param k
     * @return 
     */
    public int compareTo(DataKey k) {

        // compare the bird names
        // negative if _birdName is smaller
        // positive if _birdname is bigger
        // 0 if the same
        if (_birdSize == k.getBirdSize()) { // compare bird size
            int compare = _birdName.compareTo(k.getBirdName());
            if (compare < 0) { // _birdname comes before
                return -1;
            } else if (compare > 0) { // _birdname comes after
                return 1;
            } else { // compare == 0
                return 0;
            }
        } else if (_birdSize < k.getBirdSize()) { // this birdsize is smaller than that which it is being compared to 
            return -1;
        } else { // _birdSize > k.getBirdSize() 
            return 1;
        }

    }
}

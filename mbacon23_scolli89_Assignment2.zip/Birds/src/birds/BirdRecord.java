package birds;


/**
 * This class represents a bird record in the database. Each record consists of two
 * parts: a DataKey and the data associated with the DataKey.
 */
public class BirdRecord{

    
    private final DataKey _key;
    private final String _about;
    private final String _sound;
    private final String _image;
 

    // default constructor
    //public BirdRecord(String name,int size,String about,String sound,String image) {
    public BirdRecord (DataKey key, String about , String sound, String image){
        _key = key;
        _about = about;
        _sound = sound;
        _image = image;
    }
    public BirdRecord(String name, int size,String about, String sound, String image){  
        _key = new DataKey(name,size);
       _about = about;
       _sound = sound;
       _image = image;
        
    }
    
    public DataKey getDataKey(){
        return _key;
        
    }
    public String getAbout(){
        return _about;
    }
    public String getSound(){
        return _sound;
    }
    public String getImage(){
        return _image;
    }
     // Other constructors
 


}
